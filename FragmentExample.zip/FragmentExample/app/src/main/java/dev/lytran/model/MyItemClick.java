package dev.lytran.model;

public interface MyItemClick {
    public void click(Product p);

}
